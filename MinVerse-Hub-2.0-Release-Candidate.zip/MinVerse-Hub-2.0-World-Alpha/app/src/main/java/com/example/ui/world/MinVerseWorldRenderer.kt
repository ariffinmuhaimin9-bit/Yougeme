package com.example.ui.world

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** OpenGL ES 2.0 low-poly world renderer with a follow camera and continuous movement. */
class MinVerseWorldRenderer : GLSurfaceView.Renderer {
    @Volatile private var inputX = 0f
    @Volatile private var inputZ = 0f
    @Volatile private var jumpRequested = false
    private var playerX = 0f
    private var playerZ = 2.0f
    private var playerY = 0f
    private var verticalVelocity = 0f
    private var walkTime = 0f
    private var lastFrameNanos = 0L
    private var program = 0
    private var positionHandle = 0
    private var colorHandle = 0
    private var mvpHandle = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val vp = FloatArray(16)
    private val mvp = FloatArray(16)
    private lateinit var cube: FloatBuffer

    fun setMovement(x: Float, z: Float) { inputX = x; inputZ = z }
    fun jump() { jumpRequested = true }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.035f, 0.065f, 0.13f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vertexShader = compile(GLES20.GL_VERTEX_SHADER, """
            uniform mat4 uMVP;
            attribute vec3 aPosition;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent())
        val fragmentShader = compile(GLES20.GL_FRAGMENT_SHADER, """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent())
        program = GLES20.glCreateProgram().also {
            check(it != 0) { "OpenGL gagal mencipta shader program." }
            GLES20.glAttachShader(it, vertexShader)
            GLES20.glAttachShader(it, fragmentShader)
            GLES20.glLinkProgram(it)
            val linkStatus = IntArray(1)
            GLES20.glGetProgramiv(it, GLES20.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(it)
                GLES20.glDeleteProgram(it)
                throw IllegalStateException("OpenGL shader program gagal dipautkan: $log")
            }
        }
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
        cube = ByteBuffer.allocateDirect(CUBE.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(CUBE); position(0) }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / max(1, height).toFloat()
        Matrix.perspectiveM(projection, 0, 52f, ratio, 0.5f, 90f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastFrameNanos == 0L) 0.016f else ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastFrameNanos = now
        updatePlayer(dt)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        // Third-person camera tracks the avatar while preserving a readable view of the plaza.
        Matrix.setLookAtM(view, 0, playerX, 7.5f, playerZ + 10.5f, playerX, 0.0f, playerZ - 1.8f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
        GLES20.glUseProgram(program)
        GLES20.glEnableVertexAttribArray(positionHandle)
        cube.position(0)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 12, cube)

        // Main floating island, grass, stone rim and plaza path.
        box(0f, -1.05f, 0f, 15f, 0.85f, 13f, 0.17f, 0.29f, 0.43f)
        box(0f, -0.55f, 0f, 14.7f, 0.22f, 12.7f, 0.22f, 0.66f, 0.39f)
        box(0f, -0.40f, 1.5f, 2.8f, 0.10f, 8.5f, 0.91f, 0.73f, 0.42f)
        box(0f, -0.37f, -3.0f, 8.0f, 0.12f, 2.0f, 0.90f, 0.76f, 0.49f)

        // Spawn plaza, fountain and benches.
        box(0f, -0.24f, 0.0f, 4.4f, 0.12f, 3.6f, 0.33f, 0.48f, 0.67f)
        box(0f, -0.02f, -0.55f, 1.05f, 0.42f, 1.05f, 0.32f, 0.76f, 0.92f)
        box(0f, 0.28f, -0.55f, 0.58f, 0.16f, 0.58f, 0.68f, 0.90f, 1.0f)
        box(-2.1f, -0.25f, 0.0f, 1.0f, 0.20f, 0.38f, 0.42f, 0.29f, 0.20f)
        box(2.1f, -0.25f, 0.0f, 1.0f, 0.20f, 0.38f, 0.42f, 0.29f, 0.20f)

        // Portal gates: colored columns and lintels mark destinations.
        portal(-4.5f, -2.6f, 0.36f, 0.70f, 0.98f)
        portal(4.5f, -2.6f, 0.82f, 0.38f, 0.94f)
        portal(0f, -5.0f, 0.98f, 0.58f, 0.28f)

        // Low-poly trees and floating decorative rocks.
        for (x in listOf(-6.0f, 6.0f)) {
            for (z in listOf(-4.2f, 3.8f)) {
                box(x, -0.05f, z, 0.32f, 1.05f, 0.32f, 0.38f, 0.22f, 0.13f)
                box(x, 0.95f, z, 1.05f, 1.10f, 1.05f, 0.13f, 0.56f, 0.35f)
                box(x - 0.28f, 1.35f, z + 0.18f, 0.48f, 0.48f, 0.48f, 0.20f, 0.68f, 0.42f)
            }
        }
        box(-5.2f, -1.85f, -5.5f, 1.5f, 0.9f, 1.2f, 0.24f, 0.34f, 0.53f)
        box(5.4f, -1.7f, -5.8f, 1.1f, 1.0f, 1.3f, 0.30f, 0.38f, 0.58f)

        // Player avatar with a subtle walking animation.
        val moving = (kotlin.math.abs(inputX) + kotlin.math.abs(inputZ)) > 0.12f
        val legSwing = if (moving) sin(walkTime * 10f) * 0.18f else 0f
        box(playerX, playerY + 0.10f, playerZ, 0.66f, 0.88f, 0.46f, 0.16f, 0.53f, 0.95f)
        box(playerX, playerY + 0.84f, playerZ, 0.54f, 0.54f, 0.54f, 0.98f, 0.78f, 0.58f)
        box(playerX - 0.19f, playerY - 0.40f + legSwing, playerZ, 0.20f, 0.42f, 0.23f, 0.10f, 0.15f, 0.29f)
        box(playerX + 0.19f, playerY - 0.40f - legSwing, playerZ, 0.20f, 0.42f, 0.23f, 0.10f, 0.15f, 0.29f)
        box(playerX - 0.43f, playerY + 0.08f, playerZ, 0.18f, 0.66f, 0.20f, 0.98f, 0.78f, 0.58f)
        box(playerX + 0.43f, playerY + 0.08f, playerZ, 0.18f, 0.66f, 0.20f, 0.98f, 0.78f, 0.58f)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun updatePlayer(dt: Float) {
        val magnitude = kotlin.math.sqrt(inputX * inputX + inputZ * inputZ).coerceAtLeast(1f)
        val ix = inputX / magnitude
        val iz = inputZ / magnitude
        playerX = (playerX + ix * 4.2f * dt).coerceIn(-6.4f, 6.4f)
        playerZ = (playerZ + iz * 4.2f * dt).coerceIn(-5.4f, 5.4f)
        if (kotlin.math.abs(inputX) + kotlin.math.abs(inputZ) > 0.12f) walkTime += dt
        if (jumpRequested && playerY <= 0.001f) verticalVelocity = 5.2f
        jumpRequested = false
        if (playerY > 0f || verticalVelocity > 0f) {
            verticalVelocity -= 12.5f * dt
            playerY = (playerY + verticalVelocity * dt).coerceAtLeast(0f)
            if (playerY == 0f) verticalVelocity = 0f
        }
    }

    private fun portal(x: Float, z: Float, r: Float, g: Float, b: Float) {
        box(x - 0.72f, 0.48f, z, 0.22f, 1.95f, 0.24f, r, g, b)
        box(x + 0.72f, 0.48f, z, 0.22f, 1.95f, 0.24f, r, g, b)
        box(x, 1.42f, z, 1.65f, 0.22f, 0.24f, r, g, b)
        box(x, -0.43f, z, 1.9f, 0.10f, 0.55f, r * 0.7f, g * 0.7f, b * 0.7f)
    }

    private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, r: Float, g: Float, b: Float) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
        GLES20.glUniform4f(colorHandle, r, g, b, 1f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun compile(type: Int, source: String): Int = GLES20.glCreateShader(type).also { shader ->
        check(shader != 0) { "OpenGL gagal mencipta shader." }
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw IllegalStateException("OpenGL shader gagal dikompil: $log")
        }
    }

    companion object {
        private val CUBE = floatArrayOf(
            -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f,0.5f,0.5f,
            -0.5f,-0.5f, 0.5f,  0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
        )
    }
}

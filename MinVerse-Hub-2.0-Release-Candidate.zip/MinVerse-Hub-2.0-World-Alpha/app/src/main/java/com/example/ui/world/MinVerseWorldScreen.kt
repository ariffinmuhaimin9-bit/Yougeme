package com.example.ui.world

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.sqrt

/** Playable local MinVerse World scene. Online/local network sync is a separate milestone. */
@Composable
fun MinVerseWorldScreen(
    playerName: String,
    avatarEmoji: String,
    onBack: () -> Unit,
    onOpenGames: () -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var surface by remember { mutableStateOf<MinVerseGLSurfaceView?>(null) }
    DisposableEffect(lifecycleOwner, surface) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> surface?.onResume()
                Lifecycle.Event.ON_PAUSE -> surface?.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            surface?.onPause()
        }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF10182B))) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx -> MinVerseGLSurfaceView(ctx).also { surface = it } },
            update = { surface = it }
        )
        Column(
            Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MINVERSE WORLD", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                    Text("Selamat datang, $playerName", color = Color(0xFFB8C7E8), fontSize = 12.sp)
                }
                OutlinedButton(onClick = onBack) { Text("Keluar") }
            }
            Surface(color = Color(0xCC172641), shape = MaterialTheme.shapes.medium) {
                Text("WORLD ALPHA  •  Jelajah pulau, cari portal permainan", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
            }
        }

        // Touch joystick: drag direction is normalized and continuously applied by the renderer.
        WorldJoystick(
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 24.dp),
            onMove = { x, y -> surface?.setMovement(x, y) }
        )
        Column(Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 22.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(onClick = { surface?.jump() }) { Text("⬆ Lompat") }
            Button(onClick = onOpenGames) { Text("Pilih permainan  →") }
        }
        Surface(
            color = Color(0xCC172641), shape = CircleShape,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)
        ) {
            Text("$avatarEmoji  $playerName", color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 11.sp)
        }
        Text("Gerakkan joystick untuk berjalan • Lompat untuk melepasi platform", color = Color(0xFFE3EAF8), fontSize = 10.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 82.dp))
    }
}

@Composable
private fun WorldJoystick(modifier: Modifier = Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    var radius by remember { mutableFloatStateOf(1f) }
    Canvas(
        modifier.size(132.dp).pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { p ->
                    radius = size.width * 0.34f
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val delta = p - center
                    val length = sqrt(delta.x * delta.x + delta.y * delta.y).coerceAtLeast(1f)
                    val scale = (radius / length).coerceAtMost(1f)
                    knob = delta * scale
                    onMove((knob.x / radius).coerceIn(-1f, 1f), (knob.y / radius).coerceIn(-1f, 1f))
                },
                onDrag = { change, drag ->
                    change.consume()
                    val maxRadius = size.width * 0.34f
                    val next = knob + drag
                    val length = sqrt(next.x * next.x + next.y * next.y).coerceAtLeast(1f)
                    val scale = (maxRadius / length).coerceAtMost(1f)
                    knob = next * scale
                    onMove((knob.x / maxRadius).coerceIn(-1f, 1f), (knob.y / maxRadius).coerceIn(-1f, 1f))
                },
                onDragEnd = { knob = Offset.Zero; onMove(0f, 0f) },
                onDragCancel = { knob = Offset.Zero; onMove(0f, 0f) }
            )
        }
    ) {
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(Color(0x663B5680), radius = size.minDimension * 0.48f, center = c)
        drawCircle(Color(0xCC9CB8E8), radius = size.minDimension * 0.48f, center = c, style = Stroke(width = 3.dp.toPx()))
        drawCircle(Color(0xFFDAE7FF), radius = size.minDimension * 0.19f, center = c + knob)
    }
}

class MinVerseGLSurfaceView(context: android.content.Context) : android.opengl.GLSurfaceView(context) {
    private val worldRenderer = MinVerseWorldRenderer()
    init {
        setEGLContextClientVersion(2)
        setRenderer(worldRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause = true
    }
    fun setMovement(x: Float, y: Float) { worldRenderer.setMovement(x, y) }
    fun jump() { worldRenderer.jump() }
}
